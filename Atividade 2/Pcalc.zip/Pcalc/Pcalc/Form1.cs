﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado; //globais 
        public Form1()
        {
            InitializeComponent();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 * numero2).ToString();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero2.Text, out numero2))
            {
                errorProvider1.SetError(txtnumero2, "Número 2 inválido");
                txtnumero2.Focus();
            }
            else
            {
                errorProvider1.SetError(txtnumero2, "");
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 + numero2).ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 - numero2).ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 != 0)
            {
                txtresultado.Text = (numero1 / numero2).ToString();
            }
            else
            {
                MessageBox.Show("Impossível Dividir por 0!!");
            }
        }

        private void lblresultado_Click(object sender, EventArgs e)
        {

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
        
            if (MessageBox.Show("Você deseja mesmo sair?",
                "Saída", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question) == DialogResult.Yes)
            { 
             Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtnumero1, "Número 1 inválido");
                txtnumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtnumero1, "");
            }
        }
    }
}
