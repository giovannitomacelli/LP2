﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] estoque = new double[2, 4];
            string auxiliar, produtos;
            double v;
            double tam = estoque.Length;

            for (int i = 0; i < tam; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a quantidade de produtos {i + 1} na semana {j + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out estoque[i, j]))
                    {
                        MessageBox.Show("Dados Inválidos");
                        j--;
                    }
                if (auxiliar == "")
                    {
                        break;
                    }
                }
              
                produtos = "";

                for (int k = 0; k < tam; k++)
                {

                    v = estoque[k, 0] + estoque[k, 1] + estoque[k, 2] + estoque[k, 3];
                    produtos += $"O Total de produtos é {v}";
                }
                listBox1.Items.AddRange(produtos.Split('\n'));
            }
        }
                private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
